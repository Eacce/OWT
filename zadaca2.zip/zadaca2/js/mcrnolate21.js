window.addEventListener("load", function () {
    var ime = this.document.getElementById("ime");
    var prezime = this.document.getElementById("prezime");
    var mail = this.document.getElementById("mail");
    var mobitel = this.document.getElementById("mobitel");
    var brojosoba = this.document.getElementById("brojosoba");
    var mail1 = this.document.getElementById("Mail1");
    var mobitel1 = this.document.getElementById("mobitel1");
    var soba = this.document.getElementById("soba");
    var brojkreveta = this.document.getElementById("brojkreveta");
    var datum = this.document.getElementById("datum");
    var datumkraja = this.document.getElementById("datumkraja");
    var gumb = this.document.getElementById("gumb");
    var greska = this.document.getElementById("greska");
    var forma = this.document.getElementById("forma");

    ime.required = true;
    prezime.required = true;
    mail.required = true;
    mobitel.required = true;
    brojosoba.required = true;
    mail1.required = true;
    mobitel1.required = true;
    soba.required = true;
    brojkreveta.required = true;
    datum.required = true;
    datumkraja.required = true;
    
    var zaustavi = false;
    const postojiGreska = new Array(false, false, false, false, false);
    gumb.addEventListener("click", function (){
        if(ime.value == ""){
            greska.innerHTML = "Polje ime mora biti popunjeno";
            zaustavi = true;
        } else if (prezime.value == ""){
            greska.innerHTML = "Polje prezime mora biti popunjeno";
            zaustavi = true;
        }else if(mail.value == ""){
            greska.innerHTML = "Polje mail mora biti popunjeno";
            zaustavi = true;
        }else if(mobitel.value == ""){
            greska.innerHTML = "Polje mobitel mora biti popunjeno";
            zaustavi = true;
        }else if(brojosoba.value == ""){
            greska.innerHTML = "Polje broj osoba mora biti popunjeno";
            zaustavi = true;
        }else if(mobitel1.checked == false && mail1.checked == false){
            greska.innerHTML = "Odabir komunikacije mora biti odabran";
            zaustavi = true;
        }else if(soba.value == ""){
            greska.innerHTML = "Polje odabir sobe mora biti popunjeno";
            zaustavi = true;
        }else if(datum.value == ""){
            greska.innerHTML = "Datum mora biti odabran";
            zaustavi = true;
        }else if(datumkraja.value == ""){
            greska.innerHTML = "Datum kraja mora biti odabran";
            zaustavi = true;
        }
    })

    forma.addEventListener("submit", function (event) {
            if(zaustavi == true){
                event.preventDefault();
                zaustavi = false;
            }
    })

    greska.addEventListener("click", function (){
        greska.innerHTML = "";
    })

    function postojeGreske(){
        let brojac = 0;
        for(let i = 0;i < 5;i++){
            if(postojiGreska[i] == true)
                brojac++;
        }
        return brojac;
    }

    ime.addEventListener("focusout", function (){
        let re = new RegExp("[?!#<>]")
        let test = re.test(this.value);
        if(test){
            postojiGreska[0] = true;
        }else{
            postojiGreska[0] = false;
        }
        if(postojeGreske() == 0){
            greska.innerHTML = "";
        } else if(postojeGreske() == 1){
            greska.innerHTML = "Tekstualno polje ne smije sadržavati sprecijalne znakove";
        }
    })
    prezime.addEventListener("focusout", function (){
        let re = new RegExp("[?!#<>]")
        let test = re.test(this.value);
        if(test){
            postojiGreska[1] = true;
        }else{
            postojiGreska[1] = false;
        }
        if(postojeGreske() == 0){
            greska.innerHTML = "";
        } else if(postojeGreske() == 1){
            greska.innerHTML = "Tekstualno polje ne smije sadržavati sprecijalne znakove";
        }
    })

    mail.addEventListener("focusout", function (){
        let re = new RegExp("[?!#<>]")
        let test = re.test(this.value);
        if(test){
            postojiGreska[2] = true;
        }else{
            postojiGreska[2] = false;
        }
        if(postojeGreske() == 0){
            greska.innerHTML = "";
        } else if(postojeGreske() == 1){
            greska.innerHTML = "Tekstualno polje ne smije sadržavati sprecijalne znakove";
        }
    })

    mobitel.addEventListener("focusout", function (){
        let re = new RegExp("[?!#<>]")
        let test = re.test(this.value);
        if(test){
            postojiGreska[3] = true;
        }else{
            postojiGreska[3] = false;
        }
        if(postojeGreske() == 0){
            greska.innerHTML = "";
        } else if(postojeGreske() == 1){
            greska.innerHTML = "Tekstualno polje ne smije sadržavati sprecijalne znakove";
        }
    })

    soba.addEventListener("focusout", function (){
        let re = new RegExp("[?!#<>]")
        let test = re.test(this.value);
        if(test){
            postojiGreska[4] = true;
        }else{
            postojiGreska[4] = false;
        }
        if(postojeGreske() == 0){
            greska.innerHTML = "";
        } else if(postojeGreske() == 1){
            greska.innerHTML = "Tekstualno polje ne smije sadržavati sprecijalne znakove";
        }
    })

    datum.addEventListener("focusout", function (){
        let vrijednost = new Date(datum.value);
        let danas = new Date();
        
        if(vrijednost < danas){
            greska.innerHTML = "Odabrani datum je u proslosti";
        }
        else{
            greska.innerHTML = "";
        }
    })
    
    datumkraja.addEventListener("focusout", function (){
        let vrijednost = new Date(datumkraja.value);
        let danas = new Date();
        
        if(vrijednost < danas){
            greska.innerHTML = "Odabrani datum je u proslosti";
        }
        else{
            greska.innerHTML = "";
        }
    })
})
