document.addEventListener("DOMContentLoaded", function () {});

function isSmallScreen() {
	return window.innerWidth < 480;
}

if (isSmallScreen()) {
	var tableRows = document.querySelectorAll("table tr");

	tableRows.forEach(function (row) {
		row.addEventListener("mouseenter", function () {
			var tableId = row.closest("table").id;
			var additionalInfo = document.querySelector("#" + tableId + "-info");
			additionalInfo.style.display = "block";
		});

		row.addEventListener("mouseleave", function () {
			var tableId = row.closest("table").id;
			var additionalInfo = document.querySelector("#" + tableId + "-info");
			additionalInfo.style.display = "none";
		});
	});
}
